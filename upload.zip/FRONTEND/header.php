<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <link rel="stylesheet" href="styles/style.css">
      <title>BitLender</title>
  </head>
  <body>

    <!-- <header>

        <nav class="nav=header-main">
            <a class="header-logo" href="#">
              <img src="#" alt="logo">
            </a>
            <ul>
              <li><a href="index.php">Home</li>
              <li><a href="#">About</li>
              <li><a href="#">Contact Us</li>
            </ul>
        </nav>

    </header> -->
