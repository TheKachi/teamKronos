# teamKronos
HNG6.0 Internship

This repo was created by and for Team Kronos. 

please the database to use for the php backend has a fullname, username, email and password column... thank you

if you want to upload to and online server, you can import the sql database hng_loginsystem.sql to the online phpmyadmin